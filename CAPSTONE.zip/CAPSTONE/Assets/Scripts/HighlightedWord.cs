[System.Serializable]
public class HighlightedWord
{
    public string word; // The word that will be highlighted
    public string meaning; // The meaning of the word
}
