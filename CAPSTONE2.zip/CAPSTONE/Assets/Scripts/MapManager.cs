using UnityEngine;
using UnityEngine.SceneManagement;

public class MapSceneNavigation : MonoBehaviour
{
    public void LoadChapter(int chapterNumber)
    {
        string sceneName = "Kabanata" + chapterNumber + "_Scene1";
        SceneManager.LoadScene(sceneName);
    }

    public void LoadMap(string mapSceneName)
    {
        SceneManager.LoadScene(mapSceneName); // "map1", "map2", etc.
    }

    public void GoHome()
    {
        SceneManager.LoadScene("HomePage"); // Change if your Home scene has a different name
    }

    public void GoLogin()
    {
        SceneManager.LoadScene("Login"); // Change if your Home scene has a different name
    }
}
