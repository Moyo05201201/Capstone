﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

[System.Serializable]
public class Character
{
    public string characterName;
    public Sprite characterSprite;
}

public class DialogueManager : MonoBehaviour
{
    [System.Serializable]
    public class DialogueLine
    {
        public string characterName;
        [TextArea(2, 5)]
        public string sentence;
        public bool isLeftSide;
        public bool isNarration = false;
        public string leftCharacterToShow;
        public string rightCharacterToShow;
        public int backgroundIndex;
        public AudioClip voiceOver;
        public List<HighlightedWord> highlightedWords = new List<HighlightedWord>();
    }

    public BackgroundManager backgroundManager;
    public GameObject ChapterEndPanel;

    public Character[] characters;
    public DialogueLine[] dialogueLines;

    public Image leftCharacterImage;
    public Image rightCharacterImage;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI dialogueText;
    public Button continueButton;
    public Button backButton;
    public GameObject narrationBackground;
    public AudioSource audioSource;
    public AudioSource audioButton;

    public GameObject tooltipPanel;
    public TextMeshProUGUI tooltipText;

    public AudioClip buttonClickSound;

    private int currentLine = 0;

    void Start()
    {
        continueButton.onClick.AddListener(NextDialogue);
        backButton.onClick.AddListener(PreviousDialogue);
        ChapterEndPanel.SetActive(false);

        nameText.text = "";
        dialogueText.text = "";
        leftCharacterImage.color = new Color(1, 1, 1, 0);
        rightCharacterImage.color = new Color(1, 1, 1, 0);

        if (narrationBackground != null)
            narrationBackground.SetActive(false);

        if (tooltipPanel != null)
        {
            tooltipPanel.SetActive(true);
            CanvasGroup tooltipGroup = tooltipPanel.GetComponent<CanvasGroup>();
            if (tooltipGroup != null)
                tooltipGroup.alpha = 0f;
        }

        if (backButton != null)
            backButton.gameObject.SetActive(false); // Hide Back button at start

        ShowLine();
    }

    void ShowLine()
    {
        if (currentLine >= dialogueLines.Length || currentLine < 0) return;

        if (audioSource != null && audioSource.isPlaying)
            audioSource.Stop();

        DialogueLine line = dialogueLines[currentLine];

        // 🔥 Change background here 🔥
        if (backgroundManager != null)
        {
            backgroundManager.ChangeBackground(line.backgroundIndex);
        }

        nameText.text = line.characterName;

        string formattedSentence = line.sentence;

        // Highlight words
        foreach (HighlightedWord highlightedWord in line.highlightedWords)
        {
            formattedSentence = formattedSentence.Replace(highlightedWord.word, $"<color=#990000><u>{highlightedWord.word}</u></color>");
        }

        dialogueText.text = formattedSentence;

        // Tooltip
        CanvasGroup tooltipGroup = tooltipPanel.GetComponent<CanvasGroup>();

        if (line.highlightedWords.Count > 0)
        {
            if (tooltipGroup != null)
                tooltipGroup.alpha = 1f;

            tooltipText.text = line.highlightedWords[0].meaning;
        }
        else
        {
            if (tooltipGroup != null)
                tooltipGroup.alpha = 0f;
        }

        // Play voiceover if available
        if (audioSource != null && line.voiceOver != null)
        {
            audioSource.clip = line.voiceOver;
            audioSource.Play();
        }

        // Show or hide back button
        if (backButton != null)
        {
            if (currentLine == 0)
            {
                backButton.gameObject.SetActive(false); // Hide back button at first line
            }
            else
            {
                backButton.gameObject.SetActive(true);  // Show back button otherwise
                backButton.interactable = true;
            }
        }

        // Set left character image
        if (!string.IsNullOrEmpty(line.leftCharacterToShow))
        {
            Character leftChar = System.Array.Find(characters, c => c.characterName == line.leftCharacterToShow);
            if (leftChar != null)
            {
                leftCharacterImage.sprite = leftChar.characterSprite;
                leftCharacterImage.color = Color.white;
            }
            else
            {
                leftCharacterImage.color = new Color(1, 1, 1, 0);
            }
        }
        else
        {
            leftCharacterImage.color = new Color(1, 1, 1, 0);
        }

        // Set right character image
        if (!string.IsNullOrEmpty(line.rightCharacterToShow))
        {
            Character rightChar = System.Array.Find(characters, c => c.characterName == line.rightCharacterToShow);
            if (rightChar != null)
            {
                rightCharacterImage.sprite = rightChar.characterSprite;
                rightCharacterImage.color = Color.white;
            }
            else
            {
                rightCharacterImage.color = new Color(1, 1, 1, 0);
            }
        }
        else
        {
            rightCharacterImage.color = new Color(1, 1, 1, 0);
        }
    }

    void NextDialogue()
    {
        PlayButtonSound();
        currentLine++;

        if (currentLine < dialogueLines.Length)
        {
            ShowLine();
        }
        else
        {
            EndDialogue();
        }
    }

    void PreviousDialogue()
    {
        PlayButtonSound();
        if (currentLine > 0)
        {
            currentLine--;
            ShowLine();
        }
    }

    void EndDialogue()
    {
        nameText.text = "";
        dialogueText.text = "";
        leftCharacterImage.color = new Color(1, 1, 1, 0);
        rightCharacterImage.color = new Color(1, 1, 1, 0);
        continueButton.interactable = false;
        if (backButton != null)
            backButton.interactable = false;

        if (audioSource != null)
            audioSource.Stop();

        TriggerChapterEnd();
    }

    public void TriggerChapterEnd()
    {
        if (ChapterEndPanel != null)
            ChapterEndPanel.SetActive(true);
    }

    void PlayButtonSound()
    {
        if (audioButton != null && buttonClickSound != null)
        {
            audioButton.PlayOneShot(buttonClickSound);
        }
    }
}
