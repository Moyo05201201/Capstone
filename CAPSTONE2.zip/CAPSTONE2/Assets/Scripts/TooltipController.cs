using UnityEngine;
using TMPro;
using UnityEngine.EventSystems;

public class TooltipController : MonoBehaviour, IPointerEnterHandler
{
    public GameObject tooltipPanel;
    public TextMeshProUGUI tooltipText;

    public void OnPointerEnter(PointerEventData eventData)
    {
        // Show the tooltip panel
        tooltipPanel.SetActive(true);
    }

    public void SetTooltipText(string meaning)
    {
        tooltipText.text = meaning;
    }
}
