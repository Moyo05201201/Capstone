using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System.Collections;

public class ButtonController2 : MonoBehaviour
{
    public BackgroundManager backgroundManager;
    public int backgroundIndexToChangeTo = 0;
    public float titleDisplayDuration2 = 1f;

    public GameObject NarrationBg;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI dialogueText;
    public GameObject Continue_btn;
    public GameObject KabanataTitlePanel;

    // BGM
    public AudioSource bgmAudioSource;
    public AudioClip chapterBGM;
    public float bgmFadeInDuration = 1.5f;

    // SFX
    public AudioSource sfxAudioSource;
    public AudioClip buttonClickSound;

    private CanvasGroup BtnCanvasGrp;
    private Button Play_btn;

    void Start()
    {
        Play_btn = GetComponent<Button>();
        BtnCanvasGrp = GetComponent<CanvasGroup>();
        Play_btn.onClick.AddListener(OnButtonClick2);

        // Hide elements initially
        if (NarrationBg != null) NarrationBg.SetActive(false);
        if (nameText != null) nameText.gameObject.SetActive(false);
        if (dialogueText != null) dialogueText.gameObject.SetActive(false);
        if (KabanataTitlePanel != null) KabanataTitlePanel.SetActive(false);
        if (Continue_btn != null) Continue_btn.SetActive(false);

        // Setup BGM
        if (bgmAudioSource != null && chapterBGM != null)
        {
            bgmAudioSource.clip = chapterBGM;
            bgmAudioSource.volume = 0f;
            bgmAudioSource.loop = true;
            bgmAudioSource.Play();
            StartCoroutine(FadeInBGM());
        }
    }

    void OnButtonClick2()
    {
        PlaySFX();
        StartCoroutine(PlayScene2());
    }

    IEnumerator PlayScene2()
    {
        if (BtnCanvasGrp != null)
        {
            BtnCanvasGrp.alpha = 0f;
            BtnCanvasGrp.interactable = false;
            BtnCanvasGrp.blocksRaycasts = false;
        }

        if (KabanataTitlePanel != null)
            KabanataTitlePanel.SetActive(true);

        yield return new WaitForSeconds(titleDisplayDuration2);

        if (KabanataTitlePanel != null)
            KabanataTitlePanel.SetActive(false);

        if (backgroundManager != null)
        {
            backgroundManager.ChangeBackground(backgroundIndexToChangeTo);
        }

        if (NarrationBg != null) NarrationBg.SetActive(true);
        if (nameText != null) nameText.gameObject.SetActive(true);
        if (dialogueText != null) dialogueText.gameObject.SetActive(true);
        if (Continue_btn != null) Continue_btn.SetActive(true);
    }

    IEnumerator FadeInBGM()
    {
        float timer = 0f;
        while (timer < bgmFadeInDuration)
        {
            timer += Time.deltaTime;
            bgmAudioSource.volume = Mathf.Lerp(0f, 1f, timer / bgmFadeInDuration);
            yield return null;
        }
    }

    public void OnContinueNextChapter()
    {
        PlaySFX();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void OnRestartChapter()
    {
        PlaySFX();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void OnBackToMenu()
    {
        PlaySFX();
        string currentScene = SceneManager.GetActiveScene().name;
        int chapterNumber = GetChapterNumber(currentScene);

        if (chapterNumber >= 1 && chapterNumber <= 10)
            SceneManager.LoadScene("map1");
        else if (chapterNumber >= 11 && chapterNumber <= 20)
            SceneManager.LoadScene("map2");
        else if (chapterNumber >= 21 && chapterNumber <= 30)
            SceneManager.LoadScene("map3");
        else if (chapterNumber >= 31 && chapterNumber <= 39)
            SceneManager.LoadScene("map4");
        else
            Debug.LogWarning("Chapter number out of range or scene name is incorrect.");
    }

    private int GetChapterNumber(string sceneName)
    {
        // Assumes format: "KabanataX_SceneY"
        if (sceneName.StartsWith("Kabanata"))
        {
            string numberPart = sceneName.Replace("Kabanata", "").Split('_')[0];
            if (int.TryParse(numberPart, out int result))
                return result;
        }
        return -1;
    }

    void PlaySFX()
    {
        if (sfxAudioSource != null && buttonClickSound != null)
        {
            sfxAudioSource.PlayOneShot(buttonClickSound);
        }
    }
}
