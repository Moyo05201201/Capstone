using UnityEngine;
using UnityEngine.UI;

public class BackgroundManager : MonoBehaviour
{
    [Header("Assign the UI Image component used for background display")]
    public Image backgroundImage;

    [Header("Assign all background sprites in order")]
    public Sprite[] backgroundSprites;

    // Changes the background to the sprite at the given index
    public void ChangeBackground(int index)
    {
        if (index >= 0 && index < backgroundSprites.Length)
        {
            backgroundImage.sprite = backgroundSprites[index];
        }
        else
        {
            Debug.LogWarning("Background index out of range: " + index);
        }
    }
}
